/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package kanbanboard;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author user
 */
public class LoginScTest {
    
    public LoginScTest() {
    }

    @Test
    public void testLoginUser() throws Exception {
    
    LoginSc log = new LoginSc();
    
    
   } 
    
    

    @Test
    public void testMain() {
    }
    
}
